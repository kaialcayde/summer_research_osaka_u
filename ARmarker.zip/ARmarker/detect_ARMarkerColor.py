import cv2
import cv2.aruco as aruco
import numpy as np

import drivers.devices.kinect_azure.pykinectazure as pykinect_azure

pk = pykinect_azure.PyKinectAzure()
camera_intrinsics = pk.get_color_intrinsics()
# print(pk.get_color_intrinsics())


def main():
    # カメラのキャプチャを開始します
    cap = cv2.VideoCapture(0)  # 0はデフォルトのカメラを示します
    # ARマーカーの検出に使用するARマーカーの辞書を選択します（例えば、DICT_6X6_250、DICT_4X4_100など）
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)

    # マーカーの検出に使用するパラメータを設定します
    parameters = cv2.aruco.DetectorParameters()
    # parameters.minMarkerPerimeterRate = 0.4

    while True:
        # フレームをキャプチャします
        ret, frame = cap.read()

        if ret:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
            # cv2.imshow('Gray frame', gray_frame)
            # フレーム内のマーカーを検出します
            corners, ids, rejected = cv2.aruco.detectMarkers(gray_frame,
                                                             dictionary=aruco_dict,
                                                             parameters=parameters,
                                                             )

            if ids is not None:
                # マーカーが検出された場合、それを描画します
                marker_length = 0.04  # [m] ### 注意！
                # mtx = np.load("camera/mtx.npy")
                # dist = np.load("camera/dist.npy")


                frame = cv2.aruco.drawDetectedMarkers(frame, corners, ids)
                rvec, tvec, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length,
                                                                    camera_intrinsics[0],
                                                                    camera_intrinsics[1])
                for i in range(rvec[0].shape[0]):
                    cv2.drawFrameAxes(frame,
                                      camera_intrinsics[0],
                                      camera_intrinsics[1],
                                      rvec[i], tvec[i],
                                      marker_length)
                # print(rvec[0].shape)
                # print("\n\n")



            # フレームを表示します
            cv2.imshow('AR Marker Detection', frame)

        # 'q'キーが押された場合、ループを抜けてプログラムを終了します
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # キャプチャを解放し、ウィンドウを閉じます
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
