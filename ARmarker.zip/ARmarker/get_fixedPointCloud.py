import math
import pickle
import time
import numpy
import numpy as np
import basis.robot_math as rm
# import visualization.panda.world as wd
import robot_sim.robots.xarm_shuidi.xarm_shuidi as rbs
# import calibrate_xs as cxs

import drivers.devices.kinect_azure.pykinectazure as pk
import visualization.panda.world as wd
import cv2
import cv2.aruco as aruco
import time
import modeling.geometric_model as gm
import open3d as o3d
import vision.depth_camera.pcd_data_adapter as pda
import vision.depth_camera.util_functions as uf


# sensor handler
class SensorHandler:
    def __init__(self, pkx):
        self.pkx = pkx

    def get_marker_center(self):
        time.sleep(1)
        while True:
            self.pkx.device_get_capture()
            color_image_handle = self.pkx.capture_get_color_image()
            depth_image_handle = self.pkx.capture_get_depth_image()
            time.sleep(0.5)
            if color_image_handle and depth_image_handle:
                color_image = self.pkx.image_convert_to_numpy(color_image_handle)
                parameters = aruco.DetectorParameters_create()
                color_image = cv2.cvtColor(color_image, cv2.COLOR_BGRA2BGR)
                corners, ids, rejectedImgPoints = aruco.detectMarkers(color_image,
                                                                      dictionary=aruco.Dictionary_get(
                                                                          aruco.DICT_4X4_250),
                                                                      parameters=parameters)
                aruco.drawDetectedMarkers(color_image, corners, ids=ids)
                cv2.imshow("test", color_image)
                cv2.waitKey(100)
                if ids is None:
                    return None
                image_xy = np.mean(np.mean(corners[0], axis=0), axis=0).astype(np.int16)
                pcd_pnt = self.pkx.transform_color_xy_to_pcd_xyz(input_color_image_handle=color_image_handle,
                                                            input_depth_image_handle=depth_image_handle,
                                                            color_xy=image_xy)
                self.pkx.image_release(depth_image_handle)
                self.pkx.capture_release()
                print(pcd_pnt)
                return pcd_pnt

    def get_point_cloud(self):
        while True:
            self.pkx.device_get_capture()
            color_image_handle = self.pkx.capture_get_color_image()
            depth_image_handle = self.pkx.capture_get_depth_image()
            if color_image_handle and depth_image_handle:
                point_cloud = self.pkx.transform_depth_image_to_point_cloud(depth_image_handle)
                self.pkx.image_release(depth_image_handle)
                self.pkx.capture_release()
                return point_cloud


    def get_smaller_point_cloud(self):
        while True:
            self.pkx.device_get_capture(self, )
            color_image_handle = self.pkx.capture_get_color_image()
            depth_image_handle = self.pkx.capture_get_depth_image()
            if color_image_handle and depth_image_handle:
                point_cloud = self.pkx.transform_depth_image_to_point_cloud(depth_image_handle)
                self.pkx.image_release(depth_image_handle)
                self.pkx.capture_release()
                return point_cloud


base = wd.World(cam_pos=[2, 2, 2], lookat_pos=[0, 0, 0])
gm.gen_frame(thickness=.005, length=.05).attach_to(base)

range_x = [0.3, 1.0]
range_y = [-0.5, 0.5]
range_z =[-0.21, 0.1]

# obtain pointcloud images
kinect = pk.PyKinectAzure()
sensor_handler = SensorHandler(kinect)

color_image = None
depth_image = None

# 0.05, 0, 0.21 are the position indices for fix_homomat
while not(color_image and depth_image):

    kinect.device_get_capture()
    color_image = kinect.capture_get_color_image()
    depth_image = kinect.capture_get_depth_image()

    if color_image and depth_image:
        point_cloud = kinect.transform_depth_image_to_point_cloud(depth_image)
        fix_rotmat = rm.rotmat_from_axangle(axis=[1, 0, 0], angle=math.radians(-90)) @ rm.rotmat_from_axangle(axis=[0, 1, 0], angle=math.radians(90))
        fix_homomat = rm.homomat_from_posrot(pos=[0, 0, 0], rot=fix_rotmat)
        # point_cloud_geometric = gm.GeometricModel(initor=point_cloud)
        point_cloud_numpy = rm.homomat_transform_points(fix_homomat, point_cloud)
        print(point_cloud_numpy)
        np.savetxt("point_cloud_numpy.txt", point_cloud_numpy)

        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 0] >= range_x[0]]
        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 0] <= range_x[1]]
        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 1] >= range_y[0]]
        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 1] <= range_y[1]]
        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 2] >= range_z[0]]
        # point_cloud_numpy = point_cloud_numpy[point_cloud_numpy[:, 2] <= range_z[1]]
        np.savetxt("point_cloud_numpy_fixed.txt", point_cloud_numpy)

        point_cloud_geometric = gm.GeometricModel(initor=point_cloud_numpy)
        point_cloud_geometric.attach_to(base)
base.run()
