import drivers.devices.kinect_azure.pykinectazure as pykinect_azure

pk = pykinect_azure.PyKinectAzure()
print(pk.get_color_intrinsics())
