# import vision.ar_markers.make_pdfboard as mpb
import vision.ar_marker.make_pdfboard as mpb
import cv2.aruco as aruco

mpb.make_aruco_board(nrow=1, ncolumn =1, # マ ー カ ー の 行 数 と 列 数
marker_dict=aruco.DICT_4X4_250 , # cv2.aruco.Dictionary_get は 内 部 で 実 施
start_id =2, marker_size =60, # ID2 か ら ， 外 接 正 方 形 の 辺 長 を 60 ㎜ に す る
savepath='./', name='test ', # こ の コ ー ド と 同 じ フ ォ ル ダ の 下 に 保 存
frame_size =(100 ,100) , # カ ッ ト し や す い た め の 枠
paper_width =210, paper_height =297) # A4 サ イ ズ の 印 刷 用 紙
