import numpy as np
import math
import time
import cv2
import basis.robot_math as rm
import modeling.geometric_model as gm
import visualization.panda.world as wd
import robot_sim.robots.xarm_shuidi.xarm_shuidi as xarm_sim
import robot_con.xarm_shuidi.xarm_shuidi_x as xarm_act

import drivers.devices.kinect_azure.pykinectazure as pykinect_azure


base = wd.World(cam_pos=[0.5, 0.5, 0.5], lookat_pos=[0, 0, 0])


#  get camera intrinsics
pk = pykinect_azure.PyKinectAzure()
camera_intrinsics = pk.get_color_intrinsics()
cam_mat = camera_intrinsics[0]
dist_coeff = camera_intrinsics[1]


def main():
    # starting capture
    cap = cv2.VideoCapture(0)  # 0 indicates default camera
    # select AR marker type
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
    # setting parameter for detecting markers
    parameters = cv2.aruco.DetectorParameters()
    # parameters.minMarkerPerimeterRate = 0.4

    # # pre set variables
    R_camera_to_marker = np.eye(3)
    T_camera_to_marker = np.array([1, 0, 0])

    while True:
        # capture
        ret, frame = cap.read()

        if ret:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # cv2.imshow('Gray frame', gray_frame)

            # detect markers
            corners, ids, rejected = cv2.aruco.detectMarkers(gray_frame,
                                                             dictionary=aruco_dict,
                                                             parameters=parameters,
                                                             )
            if ids is not None:
                marker_length = 0.04  # [m]

                frame = cv2.aruco.drawDetectedMarkers(frame, corners, ids)
                rvec, tvec, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length,
                                                                    cam_mat, dist_coeff)
                # for i in range(rvec[0].shape[0]):
                #     cv2.drawFrameAxes(frame,
                #                       camera_intrinsics[0],
                #                       camera_intrinsics[1],
                #                       rvec[i], tvec[i],
                #                       marker_length)
                #     print(rvec[i], tvec[i])

                for i in range(rvec[0].shape[0]):
                    cv2.drawFrameAxes(frame,
                                      camera_intrinsics[0],
                                      camera_intrinsics[1],
                                      rvec[i], tvec[i],
                                      marker_length)
                    print(rvec[i], tvec[i])

                R_marker_to_camera = cv2.Rodrigues(rvec)[0]
                print(R_marker_to_camera)
                # R_T = R.T
                T_marker_to_camera = tvec[0].T


                R_camera_to_marker = np.linalg.pinv(R_marker_to_camera)
            print(np.linalg.det(R_camera_to_marker))
                T_camera_to_marker = -T_marker_to_camera

                # print(rvec[0][0], tvec[0][0])
                gm.gen_frame(pos=np.array(T_camera_to_marker), rotmat=R_camera_to_marker).attach_to(base)
                # print(rvec[0].shape)
                # print("\n\n")

                # display frame
                cv2.imshow('AR Marker Detection', frame)
                # cv2.waitKey(0)
                base.run()
                # break

# # camera location
# cam_rotmat = rm.rotmat_from_axangle(axis=[1, 0, 0], angle=math.radians(-90)) @ rm.rotmat_from_axangle(axis=[0, 1, 0], angle=math.radians(90))
# cam_homomat = rm.homomat_from_posrot(pos=[0, 0, 0], rot=cam_rotmat)
#
# # combine camera location with AR marker location
# ar_rotmat = cam_rotmat @ R_camera_to_marker
# ar_homomat = rm.homomat_from_posrot(pos=T_camera_to_marker, rot=ar_rotmat)
#
#
#
#
# # initialize sim
# rbt_s = xarm_sim.XArmShuidi(enable_cc=True)
# homeconf_jnt_values = rbt_s.get_jnt_values()
#
# # initialize real robot
# rbt_x = xarm_act.XArmShuidiX(ip="10.2.0.201")
#
# # obtain current joint values
# current_jnt_values = rbt_x.arm_get_jnt_values()
#
# # move arm to homeconf
# rbt_x.arm_move_jspace_path([current_jnt_values, homeconf_jnt_values])
#
# # obtain joint values to move to start location of ar marker
# # starting_joint_values = rbt.
# #tcp is gripper
# # current_tcp_pos, current_tcp_rot = rbt_s.get_gl_tcp()
# # marker_homomat = rm.homomat_from_posrot(pos=current_tcp_pos + np.array([0.1, 0, 0]),
# #                                         rot=current_tcp_rot)
# # tgt_jnt_values = rbt_s.ik(tgt_pos=marker_homomat[:3, 3], tgt_rotmat=marker_homomat[:3, :3])
#
# current_tcp_pos, current_tcp_rot = rbt_s.get_gl_tcp()
# marker_homomat = rm.homomat_from_posrot(pos = current_tcp_pos + T_camera_to_marker,
#                                         rot = R_camera_to_marker)
# tgt_jnt_values = rbt_s.ik(tgt_pos=marker_homomat[:3, 3], tgt_rotmat=marker_homomat[:3, :3])
#
#
#
#
# # move arm to the marker's location
# rbt_x.arm_move_jspace_path([rbt_x.arm_get_jnt_values(), tgt_jnt_values])
# rbt_x.arm_move_jspace_path([rbt_x.arm_get_jnt_values(), homeconf_jnt_values])
#
#
#
# # back to start pose
# # xarm_act.XArmShuidiX.arm_move_jspace_path()


if __name__ == '__main__':
    main()
