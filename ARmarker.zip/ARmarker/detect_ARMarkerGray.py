import cv2
import cv2.aruco as aruco
import numpy as np

import drivers.devices.kinect_azure.pykinectazure as pykinect_azure

#  get camera intrinsics
pk = pykinect_azure.PyKinectAzure()
camera_intrinsics = pk.get_color_intrinsics()
cam_mat = camera_intrinsics[0]
dist_coeff = camera_intrinsics[1]


def main():
    # starting capture
    cap = cv2.VideoCapture(0)  # 0 indicates default camera
    # select AR marker type
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
    # setting parameter for detecting markers
    parameters = cv2.aruco.DetectorParameters()
    # parameters.minMarkerPerimeterRate = 0.4

    while True:
        # capture
        ret, frame = cap.read()

        if ret:
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # cv2.imshow('Gray frame', gray_frame)

            # detect markers
            corners, ids, rejected = cv2.aruco.detectMarkers(gray_frame,
                                                             dictionary=aruco_dict,
                                                             parameters=parameters,
                                                             )
            if ids is not None:
                marker_length = 0.04  # [m]

                frame = cv2.aruco.drawDetectedMarkers(frame, corners, ids)
                rvec, tvec, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length,
                                                                    cam_mat,  dist_coeff)
                for i in range(rvec[0].shape[0]):
                    cv2.drawFrameAxes(frame,
                                      camera_intrinsics[0],
                                      camera_intrinsics[1],
                                      rvec[i], tvec[i],
                                      marker_length)
                # print(rvec[0].shape)
                # print("\n\n")
                # フレームを表示します
                cv2.imshow('AR Marker Detection', frame)
                break


    # キャプチャを解放し、ウィンドウを閉じます
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
